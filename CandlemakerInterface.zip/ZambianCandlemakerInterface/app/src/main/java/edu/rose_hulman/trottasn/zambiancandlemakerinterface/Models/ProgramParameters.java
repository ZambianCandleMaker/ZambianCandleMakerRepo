package edu.rose_hulman.trottasn.zambiancandlemakerinterface.Models;

/**
 * Created by TrottaSN on 2/12/2016.
 */
public interface ProgramParameters {
}
