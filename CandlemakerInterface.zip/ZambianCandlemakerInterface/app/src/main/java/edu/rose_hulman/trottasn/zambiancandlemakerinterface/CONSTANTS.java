package edu.rose_hulman.trottasn.zambiancandlemakerinterface;

import android.os.Environment;

import edu.rose_hulman.trottasn.zambiancandlemakerinterface.Activities.MainActivity;

/**
 * Created by TrottaSN on 2/8/2016.
 */
public class CONSTANTS {
    public static final String PROFILES_PATH_MAIN = "Profile_CSVs";
    public static final String ADMINISTRATOR_FILES = "/Administrator_Files";
    public static final String PASSWORD_FILE_LOCATION = "/password.txt";
    public static final String PROGRAMS_PATH_MAIN = "Program_CSVs";
}
