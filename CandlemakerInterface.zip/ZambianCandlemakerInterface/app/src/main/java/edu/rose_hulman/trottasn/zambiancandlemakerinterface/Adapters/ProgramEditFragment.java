package edu.rose_hulman.trottasn.zambiancandlemakerinterface.Adapters;

import edu.rose_hulman.trottasn.zambiancandlemakerinterface.Models.DipProgram;

/**
 * Created by TrottaSN on 2/14/2016.
 */
public interface ProgramEditFragment {
    void switchToEditing(DipProgram dipProgram);
    void onProgramDeleted(DipProgram dipProgram, int positionInAdapter);
}
