package edu.rosehulman.lairdjl.charttest;

/**
 * Created by Jake on 1/27/16.
 */
public class PosTimePair {

    private int pos;
    private int time;

    public PosTimePair(int pos, int time){
        this.pos = pos;
        this.time = time;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
}
