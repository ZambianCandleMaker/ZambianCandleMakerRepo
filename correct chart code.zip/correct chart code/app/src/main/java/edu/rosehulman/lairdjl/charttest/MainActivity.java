package edu.rosehulman.lairdjl.charttest;

import android.app.Dialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.TintManager;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

import java.sql.Array;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private String DEBUG_TAG = "";
    GraphView graph;

    DataPoint[] dp;
    private LineGraphSeries<DataPoint> currentSeries;

    private Spinner dropdown;
    private HashMap<String, String> profileSet = new HashMap<String, String>();
    private String TEST_PROFILE_1 = "<[0:0],[1:500],[1:1000],[2:3000],[3:4000],[2:4800],[0:6000]>";
    private String TEST_PROFILE_2 = "<[0:0],[1:800],[1:1000],[2:2000],[3:3000],[5:3500],[3:4800],[0:6000]>";

    private Menu menu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                insertPointDialog();
            }
        });




        profileSet.put("Profile 1",TEST_PROFILE_1);
        profileSet.put("Profile 2", TEST_PROFILE_2);



        currentSeries = profileToSeries(TEST_PROFILE_2);
        graph = (GraphView) findViewById(R.id.graph);

        currentSeries.setDrawDataPoints(true);
        graph.addSeries(currentSeries);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public LinkedList<PosTimePair> readProfile(String profile){
        LinkedList l = new LinkedList();
        int pos;
        int time;

        for(int i = 0; i < profile.length(); i++){

            if(profile.charAt(i) == '['){
                String s="";
                for(i++;profile.charAt(i) != ':';i++){
                    s = s + profile.charAt(i);
                }

                pos = Integer.parseInt(s);
                s = "";
                for(i++;profile.charAt(i) != ']';i++){
                    s = s + profile.charAt(i);
                }
                time = Integer.parseInt(s);
                l.add(new PosTimePair(pos,time));
            }

        }

        return l;

    }

    public LineGraphSeries<DataPoint> insertPoint(LinkedList<PosTimePair> list, int time, int position){

        ListIterator<PosTimePair> i = list.listIterator();
        int lastTime = 0;
        int x = 0;
        PosTimePair newPosTime = new PosTimePair(position,time);
        while(i.hasNext()){
            PosTimePair current = (PosTimePair) i.next();
            if(current.getTime() > time && time > lastTime) {
                i.set(newPosTime);
                i.add(current);
                break;
            }
            else if(current.getTime() == time){
                i.set(newPosTime);
                break;
            }
            else if(!i.hasNext()) i.add(newPosTime);

            lastTime = current.getTime();
            x++;
        }

        return getLineGraphSeries(list);
    }

    public LineGraphSeries<DataPoint> getLineGraphSeries(LinkedList<PosTimePair> link){
        Iterator<PosTimePair> i = link.listIterator();

        ArrayList<DataPoint> sList = new ArrayList<DataPoint>();

        while(i.hasNext()){
            PosTimePair p = i.next();
            sList.add(new DataPoint(p.getTime(),p.getPos()));
        }

        dp = sList.toArray(new DataPoint[sList.size()]);
        return new LineGraphSeries<DataPoint>(dp);
    }

    public LineGraphSeries<DataPoint> profileToSeries(String profile){
        return getLineGraphSeries(readProfile(profile));
    }

    public LinkedList<PosTimePair> seriesToLinkedList(LineGraphSeries<DataPoint> series){
        LinkedList<PosTimePair> linkedList = new LinkedList<PosTimePair>();
        Iterator<DataPoint> i = series.getValues(0,series.getHighestValueX());
        while (i.hasNext()){
            DataPoint d = i.next();
            linkedList.add(new PosTimePair((int) d.getY(),(int) d.getX()));
        }

        return linkedList;
    }

    private void showSwitchDialog(){
        DialogFragment df = new DialogFragment(){
            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState){

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                View view = getActivity().getLayoutInflater().inflate(R.layout.profile_choose,null,false);
                final ArrayList profileList = new ArrayList (Arrays.asList(profileSet.keySet().toArray(new String[profileSet.size()])));
                dropdown = (Spinner) view.findViewById(R.id.spinner);

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_item,profileList);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                dropdown.setAdapter(adapter);

                builder.setView(view);
                builder.setTitle(getString(R.string.switch_profile));
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.setPositiveButton("ACCEPT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        currentSeries = profileToSeries(profileSet.get(dropdown.getSelectedItem().toString()));
                        graph.removeAllSeries();
                        graph.addSeries(currentSeries);
                    }
                });
                return builder.create();
            }
        };
        df.show(getSupportFragmentManager(),"search");
    }

    private void insertPointDialog(){
        DialogFragment df = new DialogFragment(){
            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState){

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());


                View view = getActivity().getLayoutInflater().inflate(R.layout.point_insert,null,false);

                final EditText editTime = (EditText) view.findViewById(R.id.editTime);
                final EditText editDepth = (EditText) view.findViewById(R.id.editDepth);


                builder.setView(view);
                builder.setTitle(getString(R.string.insert_point));
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.setPositiveButton("ACCEPT", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        graph.removeAllSeries();
                        int time = Integer.parseInt(editTime.getText().toString());
                        int pos = Integer.parseInt(editDepth.getText().toString());
                        currentSeries = insertPoint(seriesToLinkedList(currentSeries),time,pos);
                        graph.addSeries(currentSeries);
                    }
                });
                return builder.create();
            }
        };
        df.show(getSupportFragmentManager(),"search");

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_profile_switch) {
            showSwitchDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
